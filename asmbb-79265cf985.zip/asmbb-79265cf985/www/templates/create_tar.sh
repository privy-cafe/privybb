#!/bin/bash

tar -czf ./templates.tar.gz ./Light/ ./mobile/ ./Wasp/ ./MoLight/

# --exclude=*.less