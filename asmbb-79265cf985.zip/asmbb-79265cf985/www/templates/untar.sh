#!/bin/sh
rm -r ./Light/ ./mobile/ ./Wasp/ ./MoLight/
tar -xvzf ./templates.tar.gz
